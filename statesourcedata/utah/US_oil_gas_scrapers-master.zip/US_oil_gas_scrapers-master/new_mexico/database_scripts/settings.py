DATABASE = {
        'drivername': 'postgres',
        'host': 'localhost',
        'port': '5433',
        'username': 'greg',
        'password': 'lackey',
        'database': 'new_mexico',
}

